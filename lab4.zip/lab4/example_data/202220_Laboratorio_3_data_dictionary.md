|Variable|Descripción|
|---|---|
|Serial No.| Application id. Unique to each applicant |
|GRE Score| The Graduate Record Examination. An exam designed to measure overall academic readiness. 0 to 340 |
|TOEFL Score| Score in the Test of English as a Foreign Language obtained by the applicant. 0 to 120 |
|University Rating| Quality of the university where the applicant graduated. 0 to 5 |
|SOP| Statement of Purpose Strength. 0 to 5 |
|LOR| Letter of recomendation Strength. 0 to 5 |
|CPGA| Cumulative Grade Point Average. An score to measure academic performance in bachelor programs. 0 to 10|
|Research Experience| Does the applicant have research experience?. Either 0 or 1|
|Admission Points| Points obtained by the applicant in the university Masters Programs admission exam. 0 to 150|
